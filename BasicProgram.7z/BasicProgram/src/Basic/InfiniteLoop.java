package Basic;

public class InfiniteLoop {

	public static void main(String[] args)
	{	
//		for(int i=0; true; i++) {
//			System.out.println("Hello");
//		}
		
		for(;;) 
		{
			System.out.println("Hello");
		}
		
	}

}
