package Exception;
/**@author ragigupt
 */

public class InvalidNumberException extends Exception {
	public InvalidNumberException(String msg) {
	System.out.println(msg);
	} 
}
